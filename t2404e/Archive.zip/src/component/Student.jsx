import { useContext, useState, useEffect } from "react";
import { CurrentUserContext } from "../App";
import * as studentService from "../service/student";
import { Link, useParams } from "react-router-dom";

export default function Student() {
  const { id } = useParams();
  const { isLoggedin } = useContext(CurrentUserContext);

  const [student, setStudent] = useState([]);

  useEffect(() => {
    const getAll = async () => {
      const result = await studentService.getStudentById(id);
      setStudent(result);
    };
    getAll();
  }, [id]);

  return (
    <>
      <section>
        {isLoggedin && (
          <>
            <h2 className="center">Student Profile: {student.name}</h2>
            <div className="student-profile">
              <div className="student-picture">
                <img src={student.pic} alt={student.name} />
              </div>
              <div className="student-info">
                <p>Student ID: {student.id} </p>
                <p>Student Name: {student.name} </p>
                <p>Student Age: {student.age} </p>
                <p>Student Address: {student.address} </p>
              </div>
            </div>
          </>
        )}
        {!isLoggedin && (
          <p>
            You must <Link to="/login">Log In</Link> to view the student info
          </p>
        )}
      </section>
    </>
  );
}
