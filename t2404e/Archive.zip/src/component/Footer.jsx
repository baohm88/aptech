function Footer() {
  return (
    <footer>
      <div>
        <p className="center"> Copyright @ 20024 - All rights resvered</p>
      </div>
      <div>Icons group</div>
    </footer>
  );
}

export default Footer;
