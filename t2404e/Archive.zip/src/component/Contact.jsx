import React from "react";

export default function Contact() {
  return (
    <section className="center">
      <h2>Contact</h2>
      <div className="flex-container form-control">
        <div>
          <iframe
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3724.104268130396!2d105.77910637636273!3d21.028513580620764!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x313454b329f9e59f%3A0xb013124dd37ad2a6!2zU-G7kSA4IFTDtG4gVGjhuqV0IFRodXnhur90LCBN4bu5IMSQw6xuaCwgVOG7qyBMacOqbSwgSMOgIE7hu5lpLCBWaWV0bmFt!5e0!3m2!1sen!2s!4v1718985275391!5m2!1sen!2s"
            width="400"
            height="300"
            style={{ border: 0 }}
            allowfullscreen=""
            loading="lazy"
            class="card"
            referrerpolicy="no-referrer-when-downgrade"
            title="map"
          ></iframe>
        </div>

        <div>
          <form action="">
            <input type="text" name="name" placeholder="Your name" required />
            <input
              type="email"
              name="email"
              placeholder="Your email"
              required
            />
            <input type="text" name="subject" placeholder="Subject" required />
            <textarea
              name="message"
              rows={5}
              placeholder="Your message"
            ></textarea>
            <p className="actions">
              <button>Login</button>
            </p>
          </form>
        </div>
      </div>
    </section>
  );
}
