import { useEffect, useState } from "react";
// import * as studentService from "../service/student";
import { saveStudent, getStudentById } from "../service/student";
import { useNavigate, useParams } from "react-router-dom";

function FormStudent() {
  const [name, setName] = useState("");
  const [pic, setPic] = useState("");
  const [address, setAddress] = useState("");
  const [age, setAge] = useState();
  const navigate = useNavigate();
  const { id } = useParams();
  const isAddMode = !id;

  const save = () => {
    const addStudent = async () => {
      await saveStudent(name, age, id, pic, address, isAddMode);
      return navigate("/students");
    };
    addStudent();
  };

  useEffect(() => {
    if (!isAddMode) {
      const getStudent = async () => {
        const std = await getStudentById(id);
        if (std) {
          setAge(std.age);
          setName(std.name);
          setAddress(std.address);
          setPic(std.pic);
        }
      };
      getStudent();
    }
  }, [id, isAddMode]);

  return (
    <>
      <section>
        <div className="new-student-form">
          <p>Add a new student: </p>
          <input type="hidden" value={id} />
          <input
            type="text"
            placeholder="Student Name"
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
          <input
            type="number"
            placeholder="Student Age"
            value={age}
            onChange={(e) => setAge(e.target.value)}
          />
          <input
            type="text"
            placeholder="Student Picture"
            value={pic}
            onChange={(e) => setPic(e.target.value)}
          />
          <input
            type="text"
            placeholder="Student Address"
            value={address}
            onChange={(e) => setAddress(e.target.value)}
          />
            <img src="" alt="" />
          <p className="actions">
            <button onClick={() => save()}>Save</button>
          </p>
        </div>
      </section>
    </>
  );
}

export default FormStudent;
