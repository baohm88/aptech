import { useContext, useEffect, useState } from "react";
// import * as studentService from "../service/student";
import * as studentService from "../service/student";
import { Link } from "react-router-dom";
import { CurrentUserContext } from "../App";

function ListStudent() {
  const { isAdmin, isLoggedin } = useContext(CurrentUserContext);
  const [students, setStudents] = useState([]);
  console.log(isAdmin, isLoggedin);

  useEffect(() => {
    const getAll = async () => {
      const result = await studentService.getAllStudent();
      setStudents(result);
    };
    getAll();
  }, []);

  const deleteStd = async (id) => {
    const stds = await studentService.deleteStudent(id);
    setStudents(stds);
  };

  return (
    <>
      {!isLoggedin && (
        <section>
          <p className="center">
            You must <Link to={"/login"}>Log In</Link> first to view students'
            info.
          </p>
        </section>
      )}
      {isLoggedin && (
        <section>
          <h2>T2404 Students</h2>
          {isAdmin && isLoggedin && (
            <Link to={"/student/form"}>
              <button>Add new Student</button>
            </Link>
          )}
          <table>
            <thead>
              <tr>
                <th className="col-1">Id</th>
                <th className="col-3">Name</th>
                {isAdmin && isLoggedin && (
                  <>
                    <th>Age</th>
                    <th>Action</th>
                  </>
                )}
              </tr>
            </thead>
            <tbody>
              {students.map((item) => (
                <tr key={item.id}>
                  <td className="center">{item.id}</td>
                  <td>
                    <Link to={"/student/" + item.id}>{item.name}</Link>
                  </td>
                  {isAdmin && isLoggedin && (
                    <>
                      <td className="center">{item.age}</td>
                      <td className="center">
                        <Link to={"/student/form/" + item.id}>
                          <button>Edit</button>
                        </Link>{" "}
                        /{" "}
                        <button onClick={() => deleteStd(item.id)}>
                          Delete
                        </button>
                      </td>
                    </>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </section>
      )}
    </>
  );
}

export default ListStudent;
