import { Link } from "react-router-dom";
import { CurrentUserContext } from "../App";

import Footer from "../component/Footer";
import { useContext } from "react";

function Layout1({ children }) {
  const { isLoggedin } = useContext(CurrentUserContext);

  return (
    <>
      <header>
        <span id="logo">
          <Link to={"/"}>
            <img
              src="https://aptech.fpt.edu.vn/wp-content/uploads/2023/03/Logo-fpt-aptech.png"
              alt="T2404E Class"
            />
          </Link>
        </span>
        <span id="nav">
          <ul>
            <li>
              <Link to={"/"}>Home</Link>
            </li>
            <li>
              <Link to={"/students"}>Students</Link>
            </li>
            <li>
              <Link to={"/contact"}>Contact</Link>
            </li>
            {!isLoggedin && (
              <li>
                <Link to={"/login"}>Login</Link>
              </li>
            )}
            {isLoggedin && (
              <li>
                <Link to={"/logout"}>Logout</Link>
              </li>
            )}
          </ul>
        </span>
      </header>

      {children}

      <Footer />
    </>
  );
}

export default Layout1;
